<div class="topspace"></div>
<footer>
    <p><a href= target="black"><strong>KARTIK AND CO</strong></a> | <a href="https://thesparksfoundationsingapore.org/" target="blank"><strong>The Sparks Foundation</strong></a></p>
</footer>